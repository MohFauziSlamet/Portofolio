import 'package:flutter/material.dart';
import 'detail_page_profile.dart';

class MainPage extends StatelessWidget {
  const MainPage({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
                gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Colors.purple[400], Colors.blue[400]])),
          ),
          Column(
            children: [
              Center(
                child: SizedBox(
                  height: 50,
                ),
              ),
              Center(
                child: Container(
                  child: Stack(
                    children: [
                      Text(
                        'Hello World',
                        style: TextStyle(
                          fontSize: 40,
                          foreground: Paint()
                            ..style = PaintingStyle.stroke
                            ..strokeWidth = 4.0
                            ..color = Colors.orange,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      Text(
                        'Hello World',
                        style: TextStyle(fontSize: 40, color: Colors.green),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 15),
              Center(
                  child: Text(
                'Welcome',
                style: TextStyle(fontSize: 40),
                textAlign: TextAlign.center,
              )),
              SizedBox(height: 5),
              Center(
                  child: Text(
                'To My Portofolio',
                style: TextStyle(fontSize: 40),
                textAlign: TextAlign.center,
              )),
              SizedBox(height: 50),
              ClipRRect(
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                  child: Image(
                    image: AssetImage("images/PictureMainPage.jpg"),
                    height: 300,
                    width: 400,
                    fit: BoxFit.cover,
                  )),
              SizedBox(height: 40),
              ElevatedButton(
                  onPressed: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) {
                      return DetailPageProfil();
                    }));
                  },
                  child: Text('About me'))
            ],
          ),
        ],
      ),
    );
  }
}
