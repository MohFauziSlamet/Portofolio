import 'package:flutter/material.dart';
import 'package:portofolio_submit/blogDart.dart';
import 'package:portofolio_submit/flutterBlog.dart';

class DetailPageProfil extends StatelessWidget {
  const DetailPageProfil({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('My Profile'),
        ),
        body: SafeArea(
            child: Column(
          children: [
            Flexible(
              flex: 4,
              child: Container(
                decoration: BoxDecoration(color: Colors.grey[100]),
                child: Row(
                  children: [
                    Flexible(
                      flex: 2,
                      child: Container(
                        decoration: BoxDecoration(color: Colors.white12),
                        child: Column(
                          children: [
                            Flexible(
                              flex: 2,
                              child: Container(
                                padding: EdgeInsets.all(25),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(30),
                                  child: Image(
                                    width: 150,
                                    height: 175,
                                    image: AssetImage('images/profile.jpg'),
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                            ),
                            Flexible(
                              flex: 4,
                              child: Container(
                                decoration:
                                    BoxDecoration(color: Colors.white12),
                                child: Column(
                                  children: [
                                    Container(
                                      padding: EdgeInsets.all(8),
                                      child: Card(
                                        elevation: 2,
                                        child: Text(
                                          'My Name is Moh Fauzi Slamet I was born in the city of Malang , July 5,1996,',
                                          style: TextStyle(fontSize: 12),
                                          textAlign: TextAlign.center,
                                        ),
                                      ),
                                    ),
                                    Container(
                                      padding: EdgeInsets.all(8),
                                      child: Card(
                                        elevation: 2,
                                        child: Column(
                                          children: [
                                            Text(
                                              'Summary Person',
                                              style: TextStyle(
                                                  fontSize: 16,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                            Text(
                                              'I have a background in vocational education, which would be useful for me to plunge in the world of work, because in smk in design to create a generation ready to work. I am also a hardworking person, principled and also sociable.',
                                              style: TextStyle(fontSize: 15),
                                            )
                                          ],
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                    Flexible(
                        flex: 3,
                        child: Container(
                          padding: EdgeInsets.all(5),
                          decoration: BoxDecoration(color: Colors.grey[300]),
                          child: ListView(
                            children: [
                              Card(
                                elevation: 2,
                                child: Column(
                                  children: [
                                    Row(
                                      children: [
                                        Icon(
                                          Icons.signal_cellular_alt_sharp,
                                          size: 40,
                                        ),
                                        Text(
                                          'My Education',
                                          style: TextStyle(
                                              fontSize: 20,
                                              fontWeight: FontWeight.w700),
                                        )
                                      ],
                                    ),
                                    Row(
                                      children: [
                                        Icon(
                                          Icons.label,
                                          size: 20,
                                        ),
                                        SizedBox(
                                          width: 5,
                                        ),
                                        Text(
                                          '2008  ',
                                          style: TextStyle(
                                              fontSize: 14,
                                              fontWeight: FontWeight.w500),
                                        ),
                                      ],
                                    ),
                                    Container(
                                      padding: EdgeInsets.only(left: 24),
                                      child: Text(
                                        'State primary school 09 Sumberpucung ',
                                        style: TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.w500),
                                      ),
                                    ),
                                    Row(
                                      children: [
                                        Icon(
                                          Icons.label,
                                          size: 20,
                                        ),
                                        SizedBox(
                                          width: 5,
                                        ),
                                        Text(
                                          '2011  ',
                                          style: TextStyle(
                                              fontSize: 14,
                                              fontWeight: FontWeight.w500),
                                        ),
                                      ],
                                    ),
                                    Container(
                                      padding: EdgeInsets.only(left: 24),
                                      child: Text(
                                        'State junior high school 01 Sumberpucung ',
                                        style: TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.w500),
                                      ),
                                    ),
                                    Row(
                                      children: [
                                        Icon(
                                          Icons.label,
                                          size: 20,
                                        ),
                                        SizedBox(
                                          width: 5,
                                        ),
                                        Text(
                                          '2014',
                                          style: TextStyle(
                                              fontSize: 14,
                                              fontWeight: FontWeight.w500),
                                        ),
                                      ],
                                    ),
                                    Container(
                                      padding: EdgeInsets.only(left: 24),
                                      child: Text(
                                        'Brantas Karangkates vocational high school ',
                                        style: TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.w500),
                                      ),
                                    ),
                                    Row(
                                      children: [
                                        Icon(
                                          Icons.label,
                                          size: 20,
                                        ),
                                        SizedBox(
                                          width: 5,
                                        ),
                                        Text(
                                          '2018 - Present',
                                          style: TextStyle(
                                              fontSize: 14,
                                              fontWeight: FontWeight.w500),
                                        ),
                                      ],
                                    ),
                                    Container(
                                      padding: EdgeInsets.only(left: 24),
                                      child: Text(
                                        'Asian Institute of Technology and Business Malang ',
                                        style: TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.w500),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: 10,
                              ),

                              /// Pengalaman (My Experience)
                              Card(
                                elevation: 2,
                                child: Column(
                                  children: [
                                    Row(
                                      children: [
                                        Icon(
                                          Icons.assignment_ind,
                                          size: 40,
                                        ),
                                        Text(
                                          'My Experience',
                                          style: TextStyle(
                                              fontSize: 20,
                                              fontWeight: FontWeight.w700),
                                        )
                                      ],
                                    ),
                                    Row(
                                      children: [
                                        Icon(
                                          Icons.label,
                                          size: 20,
                                        ),
                                        SizedBox(
                                          width: 5,
                                        ),
                                        Text(
                                          '2015 - 2021  ',
                                          style: TextStyle(
                                              fontSize: 14,
                                              fontWeight: FontWeight.w500),
                                        ),
                                      ],
                                    ),
                                    Container(
                                      padding: EdgeInsets.only(left: 24),
                                      child: Text(
                                        ' I worked for a retail company called PT Indomarco Prismata for 5th, '
                                        'and the brand name is Indomaret. My last position on Merchaindiser.'
                                        'And in July 2021, I decided to resign, and chose to pursue a career in technology.'
                                        'for 3 years I worked and studied at Intitut Teknologi dan Bisnis Asia. And now it\'s in the 6th semester',
                                        style: TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.w500),
                                        textAlign: TextAlign.justify,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Card(
                                elevation: 2,
                                child: Column(
                                  children: [
                                    Row(
                                      children: [
                                        Icon(
                                          Icons.trending_up_outlined,
                                          size: 40,
                                        ),
                                        Text(
                                          'My Expertise',
                                          style: TextStyle(
                                              fontSize: 20,
                                              fontWeight: FontWeight.w700),
                                        )
                                      ],
                                    ),
                                    Row(
                                      children: [
                                        Icon(
                                          Icons.label,
                                          size: 20,
                                        ),
                                        SizedBox(
                                          width: 5,
                                        ),
                                        Text(
                                          'DART  ',
                                          style: TextStyle(
                                              fontSize: 14,
                                              fontWeight: FontWeight.w500),
                                        ),
                                      ],
                                    ),
                                    Row(
                                      children: [
                                        Icon(
                                          Icons.label,
                                          size: 20,
                                        ),
                                        SizedBox(
                                          width: 5,
                                        ),
                                        Text(
                                          'FLUTTER  ',
                                          style: TextStyle(
                                              fontSize: 14,
                                              fontWeight: FontWeight.w500),
                                        ),
                                      ],
                                    ),
                                    Row(
                                      children: [
                                        Icon(
                                          Icons.label,
                                          size: 20,
                                        ),
                                        SizedBox(
                                          width: 5,
                                        ),
                                        Text(
                                          'Middle English Language',
                                          style: TextStyle(
                                              fontSize: 14,
                                              fontWeight: FontWeight.w500),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                              Card(
                                elevation: 2,
                                child: Column(
                                  children: [
                                    Row(
                                      children: [
                                        Icon(
                                          Icons.phone_android,
                                          size: 40,
                                        ),
                                        Text(
                                          'My Contact',
                                          style: TextStyle(
                                              fontSize: 20,
                                              fontWeight: FontWeight.w700),
                                        )
                                      ],
                                    ),
                                    Row(
                                      children: [
                                        Container(
                                            padding: EdgeInsets.only(left: 40),
                                            child: ClipRRect(
                                              child: Image(
                                                  height: 30,
                                                  width: 30,
                                                  image: AssetImage(
                                                      'images/wa.png')),
                                            )),
                                        SizedBox(
                                          width: 10,
                                        ),
                                        Text(
                                          '085731532271',
                                          style: TextStyle(
                                              fontSize: 14,
                                              fontWeight: FontWeight.w500),
                                        ),
                                      ],
                                    ),
                                    Row(
                                      children: [
                                        Container(
                                            padding: EdgeInsets.only(left: 40),
                                            child: ClipRRect(
                                              child: Image(
                                                  height: 30,
                                                  width: 30,
                                                  image: AssetImage(
                                                      'images/Facebook.png')),
                                            )),
                                        SizedBox(
                                          width: 10,
                                        ),
                                        Text(
                                          'Moh Fauzi Slamet',
                                          style: TextStyle(
                                              color: Colors.blueAccent,
                                              fontSize: 14,
                                              fontWeight: FontWeight.w500),
                                        ),
                                      ],
                                    ),
                                    Row(
                                      children: [
                                        Container(
                                            padding: EdgeInsets.only(left: 40),
                                            child: ClipRRect(
                                              child: Image(
                                                  height: 30,
                                                  width: 30,
                                                  image: AssetImage(
                                                      'images/linkedin.png')),
                                            )),
                                        SizedBox(
                                          width: 10,
                                        ),
                                        Text(
                                          'Moh Fauzi Slamet',
                                          style: TextStyle(
                                              color: Colors.blueAccent,
                                              fontSize: 14,
                                              fontWeight: FontWeight.w500),
                                        ),
                                      ],
                                    ),
                                    Row(
                                      children: [
                                        Container(
                                            padding: EdgeInsets.only(left: 40),
                                            child: ClipRRect(
                                              child: Image(
                                                  height: 30,
                                                  width: 30,
                                                  image: AssetImage(
                                                      'images/github.png')),
                                            )),
                                        SizedBox(
                                          width: 10,
                                        ),
                                        Text(
                                          'Moh Fauzi Slamet',
                                          style: TextStyle(
                                              color: Colors.blueAccent,
                                              fontSize: 14,
                                              fontWeight: FontWeight.w500),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              )
                            ],
                          ),
                        ))
                  ],
                ),
              ),
            ),
            Flexible(
              flex: 1,
              child: Container(
                color: Colors.grey[300],
                child: Column(children: [
                  Container(
                      child: Text(
                    'Coming soon my blog',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.w500),
                  )),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        GestureDetector(
                          onTap: () {
                            Navigator.push(context,
                                MaterialPageRoute(builder: (context) {
                              return BlogDart();
                            }));
                          },
                          child: Container(
                              decoration: BoxDecoration(
                                  color: Colors.blue[400],
                                  borderRadius: BorderRadius.circular(10)),
                              height: 100,
                              width: 100,
                              child: ClipRRect(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(10)),
                                child: Image(
                                  image: AssetImage('images/dart.png'),
                                  fit: BoxFit.contain,
                                ),
                              )),
                        ),
                        FloatingActionButton(
                            child: Icon(Icons.arrow_back),
                            onPressed: () {
                              Navigator.pop(context);
                            }),
                        GestureDetector(
                          onTap: () {
                            Navigator.push(context,
                                MaterialPageRoute(builder: (context) {
                              return BlogFluttert();
                            }));
                          },
                          child: Container(
                              decoration: BoxDecoration(
                                  color: Colors.blue[400],
                                  borderRadius: BorderRadius.circular(10)),
                              height: 100,
                              width: 100,
                              child: ClipRRect(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(10)),
                                child: Image(
                                  image: AssetImage('images/flutter.png'),
                                  fit: BoxFit.contain,
                                ),
                              )),
                        ),
                      ])
                ]),
              ),
            ),
          ],
        )),
      ),
    );
  }
}
