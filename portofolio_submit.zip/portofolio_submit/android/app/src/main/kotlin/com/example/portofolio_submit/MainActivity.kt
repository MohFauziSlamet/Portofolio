package com.example.portofolio_submit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
